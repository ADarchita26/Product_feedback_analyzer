
"""
The backend: a small FastAPI service that analyzes ONE product review.

Run it with:

    uv run fastapi dev api.py

Then the Streamlit app (app.py) will call this service for every review.
"""

import os

from fastapi import FastAPI
from pydantic import BaseModel
from dotenv import load_dotenv
from google import genai
from google.genai import types


# Load API key from sample.env
load_dotenv("sample.env")

api_key = os.getenv("GOOGLE_API_KEY")

if not api_key:
    raise ValueError("GOOGLE_API_KEY not found in sample.env file")


# Create Gemini client
client = genai.Client(api_key=api_key)

app = FastAPI()


# What the caller must SEND us
class Review(BaseModel):
    text: str


# What Gemini gives back and what we SEND to the caller
class Analysis(BaseModel):
    label: str
    score: int
    theme: str


@app.post("/analyze")
def analyze(review: Review):

    try:
        response = client.models.generate_content(
            model="gemini-3.8-flash",
            contents=(
                "Analyze this product review.\n"
                "label must be 'positive', 'negative', or 'neutral'.\n"
                "score must be a number from 1 (very bad) to 5 (very good).\n"
                "theme must be ONE lowercase word for the main topic "
                "(for example: battery, camera, quality, price, delivery, "
                "performance, design, usability).\n"
                f"Review: {review.text}"
            ),
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                response_schema=Analysis,
            ),
        )

        return response.parsed

    except Exception as e:
        print(f"Gemini API error: {e}")

        return {
            "label": "error",
            "score": 0,
            "theme": "error"
        }

