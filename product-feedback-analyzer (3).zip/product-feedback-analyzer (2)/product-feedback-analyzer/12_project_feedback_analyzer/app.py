
"""
The frontend: a Streamlit dashboard for a Product Review Analyzer.

Paste product reviews (one per line), click Analyze, and see the results.

This app does NOT call Gemini directly.
It calls our own backend (api.py).

Run it in a SECOND terminal while api.py is running:

    uv run streamlit run app.py
"""

from collections import Counter

import requests
import streamlit as st

# Our database code, kept in a separate file.
from database import init_db, save_results, load_history, DB_FILE


# Address of our own FastAPI backend.
API_URL = "http://127.0.0.1:8000/analyze"


# Make sure the database table exists.
init_db()


# ---------------------------------------------------------
# Page title and input
# ---------------------------------------------------------

st.title("🛍️ Product Review Analyzer")

st.write(
    "Paste product reviews below, one review per line, "
    "and click Analyze."
)

reviews_text = st.text_area(
    "Product Reviews",
    height=200
)


# ---------------------------------------------------------
# Analyze reviews
# ---------------------------------------------------------

if st.button("Analyze"):

    # Split the text box into separate reviews,
    # ignoring blank lines.
    reviews = [
        line.strip()
        for line in reviews_text.split("\n")
        if line.strip()
    ]

    if not reviews:
        st.warning("Please paste at least one product review.")

    else:

        results = []

        # Analyze each review through our FastAPI backend.
        for review in reviews:

            try:
                response = requests.post(
                    API_URL,
                    json={"text": review},
                    timeout=30
                )

                # Raise an error if FastAPI returns
                # a 4xx or 5xx response.
                response.raise_for_status()

                data = response.json()

                results.append(
                    {
                        "review": review,
                        "label": data["label"],
                        "score": data["score"],
                        "theme": data["theme"],
                    }
                )

            except Exception as e:

                # One failed review should not stop
                # the entire batch.
                results.append(
                    {
                        "review": review,
                        "label": "error",
                        "score": 0,
                        "theme": "error",
                    }
                )

        # Save results in session state so they
        # survive Streamlit reruns.
        st.session_state.results = results


# ---------------------------------------------------------
# Show results
# ---------------------------------------------------------

if "results" in st.session_state:

    results = st.session_state.results

    st.subheader("📊 Analysis Results")

    st.dataframe(
        results,
        use_container_width=True
    )


    # -----------------------------------------------------
    # Summary
    # -----------------------------------------------------

    scores = [
        r["score"]
        for r in results
        if r["label"] != "error"
    ]

    positive = [
        r
        for r in results
        if r["label"] == "positive"
    ]

    themes = [
        r["theme"]
        for r in results
        if r["theme"] != "error"
    ]


    st.subheader("📈 Summary")

    col1, col2, col3 = st.columns(3)

    # Total number of reviews
    col1.metric(
        "Total Reviews",
        len(results)
    )

    # Average product rating
    if scores:

        average_score = round(
            sum(scores) / len(scores),
            1
        )

        col2.metric(
            "Average Rating",
            f"{average_score}/5"
        )

        # Percentage of positive reviews
        positive_percentage = round(
            len(positive) / len(results) * 100
        )

        col3.metric(
            "% Positive",
            f"{positive_percentage}%"
        )


    # -----------------------------------------------------
    # Most common product topic
    # -----------------------------------------------------

    if themes:

        top_theme = Counter(themes).most_common(1)[0][0]

        st.info(
            f"Customers talk most about: **{top_theme}**"
        )


    # -----------------------------------------------------
    # Save results
    # -----------------------------------------------------

    if st.button("💾 Save to database"):

        save_results(results)

        st.success(
            f"Saved {len(results)} reviews to {DB_FILE}"
        )


# ---------------------------------------------------------
# Saved history
# ---------------------------------------------------------

with st.expander("📚 Saved history"):

    history = load_history()

    if history:

        st.write(
            f"Total saved so far: {len(history)}"
        )

        st.dataframe(
            [
                {
                    "review": r[0],
                    "label": r[1],
                    "score": r[2],
                    "theme": r[3],
                }
                for r in history
            ],
            use_container_width=True
        )

    else:

        st.write(
            "Nothing saved yet. Analyze some product reviews "
            "and click Save to database."
        )

